package org.example;

abstract class Statement {
    int line;

    public int getLine() {
        return line;
    }
}
