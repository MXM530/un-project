package org.example;public class TinyMachine {
}
