package org.example;

public enum StateType {
    START, DONE, ERROR, INID, INNUM, INASSIGN, INCOMMENT
}