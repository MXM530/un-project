package org.example;

abstract class Expression {
    int line;

    public int getLine() {
        return line;
    }
}
