package org.example;

public enum TMOpcode {
    LOAD, STORE, ADD, SUB, MUL, DIV, READ, WRITE, BR, BRPOS, BRZERO, HALT
}
