package org.example;

public enum TokenType {
    IF, ELSE, THEN, END, REPEAT, UNTIL, READ, WRITE,
    ASSIGN, LESS, EQ, PLUS, MINUS, MULTI, DIV,ADD,SUB,MUL,
    NUM, ID, ERR, LPAR, RPAR, COLON
}
