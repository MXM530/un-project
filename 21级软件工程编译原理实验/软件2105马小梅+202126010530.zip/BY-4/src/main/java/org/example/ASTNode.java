package org.example;

public class ASTNode {
    int line;
}
